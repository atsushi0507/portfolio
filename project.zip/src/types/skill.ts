export type SkillItemType = {
    name: string
    startDate: string
}