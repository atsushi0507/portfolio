export type InterestItemType = {
    icon: string
    title: string
    text: string
}