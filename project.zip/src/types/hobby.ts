export type HobbyItemType = {
    icon: string;
    title: string;
    text: string;
}