export type CareerItemType = {
    year: string;
    title: string;
    role: string;
    type: "work" | "education";
};