import { getPostBySlug, getAllSlugs } from "@/lib/posts";
import BlogContent from "./components/BlogContent";
import { notFound } from "next/navigation";

// SSG 用
export async function generateStaticParams() {
  const slugs = await getAllSlugs(); // Firestore から全 slug を取得
  return slugs.map((slug) => ({ slug }));
}

export default async function BlogPostPage({
  params,
}: {
  params: { slug: string };
}) {
  const post = await getPostBySlug(params.slug);
  if (!post) notFound();

  return <BlogContent blogData={post} />;
}
