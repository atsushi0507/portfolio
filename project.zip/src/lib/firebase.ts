import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBw6QRwuYUtq585WStluku7vaWsRavtJ6w",
  authDomain: "blog-99583.firebaseapp.com",
  projectId: "blog-99583",
  storageBucket: "blog-99583.appspot.com",
  messagingSenderId: "201330616197",
  appId: "1:201330616197:web:c3d8e3df957d82157106ec"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };